package com.example.demo.mapper;

import com.example.demo.dto.BookDto;
import com.example.demo.entity.Book;
import org.springframework.stereotype.Component;

@Component
public class BookMapper {

    public BookDto toDto(Book book) {
        BookDto dto = new BookDto();
        dto.setId(book.getId());
        dto.setName(book.getName());
        dto.setAutor(book.getAutor());
        dto.setIloscStron(book.getIloscStron());
        dto.setRokWydania(book.getRokWydania());
        dto.setWydawnictwo(book.getWydawnictwo());
        dto.setCena(book.getCena());
        return dto;
    }

    public Book toEntity(BookDto dto) {
        Book book = new Book();
        book.setId(dto.getId());
        book.setName(dto.getName());
        book.setAutor(dto.getAutor());
        book.setIloscStron(dto.getIloscStron());
        book.setRokWydania(dto.getRokWydania());
        book.setWydawnictwo(dto.getWydawnictwo());
        book.setCena(dto.getCena());
        return book;
    }
}