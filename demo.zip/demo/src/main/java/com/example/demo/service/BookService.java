package com.example.demo.service;

import com.example.demo.dto.BookDto;
import com.example.demo.entity.Book;
import com.example.demo.mapper.BookMapper;
import com.example.demo.repository.BookRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class BookService {
    private final BookRepository bookRepository;
    private final BookMapper bookMapper;

    public BookService(BookRepository bookRepository, BookMapper bookMapper) {
        this.bookRepository = bookRepository;
        this.bookMapper = bookMapper;
    }

    public BookDto getBookById(long id) {
        Optional<Book> book = bookRepository.findById(id);
        return book.map(bookMapper::toDto).orElse(null);
    }

    public void deleteBookById(long id) {
        bookRepository.deleteById(id);
    }

    public BookDto addBook(BookDto bookDto) {
        Book book = bookMapper.toEntity(bookDto);
        return bookMapper.toDto(bookRepository.save(book));
    }

    public BookDto updateBook(BookDto bookDto) {
        Book book = bookRepository.findById(bookDto.getId()).orElseThrow(() -> new RuntimeException("Book not found"));
        book.setName(bookDto.getName());
        book.setAutor(bookDto.getAutor());
        book.setIloscStron(bookDto.getIloscStron());
        book.setRokWydania(bookDto.getRokWydania());
        book.setWydawnictwo(bookDto.getWydawnictwo());
        book.setCena(bookDto.getCena());
        return bookMapper.toDto(bookRepository.save(book));
    }
}