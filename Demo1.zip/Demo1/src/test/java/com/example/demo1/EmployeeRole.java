package com.example.demo1;

public class EmployeeRole {

}
